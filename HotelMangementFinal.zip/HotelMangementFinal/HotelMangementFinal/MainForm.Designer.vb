﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnhistory = New System.Windows.Forms.Button
        Me.Label9 = New System.Windows.Forms.Label
        Me.btnAddemployee = New System.Windows.Forms.Button
        Me.btnrooms = New System.Windows.Forms.Button
        Me.btnsearch = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btncheckin = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnGuest = New System.Windows.Forms.Button
        Me.btnreserved = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnaccount = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel2.Location = New System.Drawing.Point(-44, 611)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(0, 3, 3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1337, 85)
        Me.Panel2.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(282, 308)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(125, 25)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Transaction"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(77, 308)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(127, 25)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Reservation"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(300, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 25)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Check In"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(77, 152)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 25)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Add Guest"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(52, 312)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(255, 25)
        Me.Label11.TabIndex = 9
        Me.Label11.Text = "Search Guest Information"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(108, 158)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(108, 25)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Room List"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.btnhistory)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.btnAddemployee)
        Me.GroupBox1.Controls.Add(Me.btnrooms)
        Me.GroupBox1.Controls.Add(Me.btnsearch)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(692, 249)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(482, 356)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Monitoring"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(353, 312)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 25)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Reports"
        '
        'btnhistory
        '
        Me.btnhistory.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnhistory.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.icon_infrastructure_monitoring_systems
        Me.btnhistory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnhistory.Enabled = False
        Me.btnhistory.FlatAppearance.BorderSize = 0
        Me.btnhistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnhistory.Location = New System.Drawing.Point(332, 44)
        Me.btnhistory.Name = "btnhistory"
        Me.btnhistory.Size = New System.Drawing.Size(109, 105)
        Me.btnhistory.TabIndex = 10
        Me.btnhistory.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(353, 158)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 25)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "History"
        '
        'btnAddemployee
        '
        Me.btnAddemployee.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAddemployee.BackColor = System.Drawing.Color.Transparent
        Me.btnAddemployee.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources._20151125_56550885ab810
        Me.btnAddemployee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnAddemployee.Enabled = False
        Me.btnAddemployee.FlatAppearance.BorderSize = 0
        Me.btnAddemployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddemployee.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.btnAddemployee.Location = New System.Drawing.Point(332, 209)
        Me.btnAddemployee.Name = "btnAddemployee"
        Me.btnAddemployee.Size = New System.Drawing.Size(118, 100)
        Me.btnAddemployee.TabIndex = 6
        Me.btnAddemployee.UseVisualStyleBackColor = False
        '
        'btnrooms
        '
        Me.btnrooms.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnrooms.BackColor = System.Drawing.Color.Transparent
        Me.btnrooms.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.icon_single_connected_room
        Me.btnrooms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnrooms.Enabled = False
        Me.btnrooms.FlatAppearance.BorderSize = 0
        Me.btnrooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrooms.Location = New System.Drawing.Point(95, 55)
        Me.btnrooms.Name = "btnrooms"
        Me.btnrooms.Size = New System.Drawing.Size(121, 100)
        Me.btnrooms.TabIndex = 6
        Me.btnrooms.UseVisualStyleBackColor = False
        '
        'btnsearch
        '
        Me.btnsearch.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnsearch.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.Untitled_3
        Me.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnsearch.Enabled = False
        Me.btnsearch.FlatAppearance.BorderSize = 0
        Me.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsearch.Location = New System.Drawing.Point(107, 204)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(109, 98)
        Me.btnsearch.TabIndex = 4
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.btncheckin)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.btnGuest)
        Me.GroupBox2.Controls.Add(Me.btnreserved)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(86, 249)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(487, 356)
        Me.GroupBox2.TabIndex = 13
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Transaction"
        '
        'btncheckin
        '
        Me.btncheckin.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btncheckin.BackColor = System.Drawing.Color.Transparent
        Me.btncheckin.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.check_1_icon
        Me.btncheckin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btncheckin.Enabled = False
        Me.btncheckin.FlatAppearance.BorderSize = 0
        Me.btncheckin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncheckin.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btncheckin.Location = New System.Drawing.Point(285, 56)
        Me.btncheckin.Margin = New System.Windows.Forms.Padding(0)
        Me.btncheckin.Name = "btncheckin"
        Me.btncheckin.Size = New System.Drawing.Size(122, 101)
        Me.btncheckin.TabIndex = 3
        Me.btncheckin.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button1.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.c
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button1.Enabled = False
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(285, 209)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(122, 101)
        Me.Button1.TabIndex = 7
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnGuest
        '
        Me.btnGuest.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnGuest.BackColor = System.Drawing.Color.Transparent
        Me.btnGuest.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.Quest1_Icon_1024x1024
        Me.btnGuest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnGuest.Enabled = False
        Me.btnGuest.FlatAppearance.BorderSize = 0
        Me.btnGuest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnGuest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.btnGuest.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnGuest.Location = New System.Drawing.Point(62, 55)
        Me.btnGuest.Name = "btnGuest"
        Me.btnGuest.Size = New System.Drawing.Size(128, 94)
        Me.btnGuest.TabIndex = 1
        Me.btnGuest.UseVisualStyleBackColor = False
        '
        'btnreserved
        '
        Me.btnreserved.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnreserved.BackColor = System.Drawing.Color.Transparent
        Me.btnreserved.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources.SEARCH_AND_RESERVE_ICON_01_300x300
        Me.btnreserved.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnreserved.Enabled = False
        Me.btnreserved.FlatAppearance.BorderSize = 0
        Me.btnreserved.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.btnreserved.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.btnreserved.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreserved.Location = New System.Drawing.Point(70, 204)
        Me.btnreserved.Name = "btnreserved"
        Me.btnreserved.Size = New System.Drawing.Size(120, 101)
        Me.btnreserved.TabIndex = 2
        Me.btnreserved.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources._1_Monbela_Tourist_Inn_Kabankalan_City__Negros_Occidental_Philippines
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.btnaccount)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(-44, -97)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(0, 3, 3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1316, 340)
        Me.Panel1.TabIndex = 10
        '
        'btnaccount
        '
        Me.btnaccount.BackColor = System.Drawing.Color.Transparent
        Me.btnaccount.BackgroundImage = Global.HotelMangementFinal.My.Resources.Resources._012_power_512
        Me.btnaccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnaccount.FlatAppearance.BorderSize = 0
        Me.btnaccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaccount.Location = New System.Drawing.Point(1207, 129)
        Me.btnaccount.Name = "btnaccount"
        Me.btnaccount.Size = New System.Drawing.Size(83, 65)
        Me.btnaccount.TabIndex = 7
        Me.btnaccount.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightGray
        Me.Label2.Location = New System.Drawing.Point(497, 290)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(407, 50)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Hotel Management"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.HotelMangementFinal.My.Resources.Resources.VDFFVFV
        Me.PictureBox1.Location = New System.Drawing.Point(269, 129)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(847, 255)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(1258, 647)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MainForm"
        Me.Text = "MainForm"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnAddemployee As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnrooms As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnsearch As System.Windows.Forms.Button
    Friend WithEvents btncheckin As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnGuest As System.Windows.Forms.Button
    Friend WithEvents btnreserved As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnhistory As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnaccount As System.Windows.Forms.Button
End Class
