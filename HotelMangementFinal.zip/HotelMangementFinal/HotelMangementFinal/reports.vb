﻿Public Class reports

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "dd/MM/yyyy"
        hotelreports("SELECT tblcheckout.[ID], tblcheckout.[GUESTNAME], tblcheckout.[ROOM_NO], tblcheckout.[ROOM_TYPE], tblcheckout.[ROOM_RATE], tblcheckout.[CHECKIN_DATE], tblcheckout.[NOOFDAYS], tblcheckout.[NOOFADULTS], tblcheckout.[NOOFCHILDREN], tblcheckout.[ADVANCE], tblcheckout.[REMARKS], tblcheckout.[CHECKOUT_DATE], tblcheckout.[CASH]FROM(tblcheckout)WHERE(tblcheckout.[CHECKOUT_DATE] = #" & DateTimePicker1.Value & "#)", "CrystalReport2")

    End Sub
End Class