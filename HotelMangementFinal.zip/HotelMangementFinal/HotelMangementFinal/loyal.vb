﻿Public Class loyal

End Class